// Copyright 2020 Honeby.
// License: MIT
// Author: Honbey
//
// Contain definition of function about watermark.

#ifndef MWATSON_SRC_WATERMARK_H_
#define MWATSON_SRC_WATERMARK_H_

#include "src/mwatson.h"

bool *GetWatermarkArray(const cv::Mat src_logo);
void InsertWatermark(cv::VideoCapture src_video, const bool *bit_stream, bool model=true);
void GetWatermark(cv::VideoCapture src_video);

#endif // MWATSON_SRC_WATERMARK_H_
