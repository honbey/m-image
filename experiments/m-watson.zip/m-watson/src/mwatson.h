// Copyright 2020 Honeby.
// License: MIT
// Author: Honbey
//
//

#ifndef MWATSON_SRC_MWATSON_H_
#define MWATSON_SRC_MWATSON_H_

#include <opencv2/opencv.hpp>
#include <openssl/ssl.h>
#include <fstream>

#define PATH "/Volumes/DISK/WorkSpace/data/m-watson"
#define DIFF_RATIO 0.93
#define THRESHOLD_VALUE 10

#define EIGHT 8
#define LOGO_HEIGHT 50
#define LOGO_WIDTH  100

#define SETONE(x,y) (x)|=(1<<(y))  // set the bit value to 1 of the y-th bit of x
#define SETCLR(x,y) (x)&=~(1<<(y)) // set the bit value to 0 of the y-th bit of x
#define GETBIT(x,y) (x)&(1<<(y))   // get the bit value of the y-th bit of x

long* GetKeyFrameByFile();

#endif // MWATSON_SRC_MWATSON_H_
