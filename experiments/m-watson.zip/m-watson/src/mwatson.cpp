// Copyright 2020 Honeby.
// License: MIT
// Author: Honbey
//
//

#include "src/mwatson.h"

long* GetKeyFrameByFile() {
  std::fstream frame_index;
  frame_index.open("frame-index.txt");
  std::vector<std::string> tmp_vec;
  std::string tmp = "";
  int len = 0;
  for ( ; getline(frame_index, tmp); ++len) {
     tmp_vec.push_back(tmp);
  }
  long *dst_array = new long[len+1];
  dst_array[0] = len;
  for (int i = 1; i <= len; i++) {
    dst_array[i] = std::stol(tmp_vec[i-1]);
  }
  frame_index.close();
  return dst_array;
}
