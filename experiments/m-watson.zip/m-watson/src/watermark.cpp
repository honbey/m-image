// Copyright 2020 Honeby.
// License: MIT
// Author: Honbey
//
// we can convert watermark(logo) to bit stream,
// then we modify DCT parameter by a bool array.

#include "src/watermark.h"
#include "src/keyframe.h"
#include "src/operateframe.h"

bool *GetWatermarkArray(const cv::Mat src_logo) {
  cv::Mat n_logo = cv::Mat::zeros(LOGO_HEIGHT, LOGO_WIDTH, src_logo.type());
  cv::resize(src_logo, n_logo, cv::Size(LOGO_WIDTH, LOGO_HEIGHT));
  cv::cvtColor(n_logo, n_logo, cv::COLOR_BGR2GRAY);
  cv::adaptiveThreshold(n_logo, n_logo, 255, cv::ADAPTIVE_THRESH_MEAN_C, cv::THRESH_BINARY, 255, 0.0);
//  cv::imshow("T", n_logo);cv::waitKey(0);
  bool *bit_stream = new bool[LOGO_HEIGHT*LOGO_WIDTH];
  for (int i = 0, k = 0; i < LOGO_HEIGHT; ++i) {
    for (int j = 0; j < LOGO_WIDTH; ++j) {
      if (n_logo.at<uchar>(i, j) > 0)
        bit_stream[k] = true;
      else bit_stream[k] = false;
      // printf("%u ", bit_stream[k]);
      k++;
    }
  }
  return bit_stream;
}

void InsertWatermark(cv::VideoCapture src_video, const bool *bit_stream, bool model) {
  // no necessary to reduce the map size, the key frame is useful.
  // because i want select the key frame randomly in the future.
  // now select key frame randomly
  std::vector<cv::Mat> op_frames, frame_vector;
  long* key_frame_pos = GetKeyFrameByFile();
  for (int i = 0; i < key_frame_pos[0]; i++) {
    src_video.set(cv::CAP_PROP_POS_FRAMES, key_frame_pos[i+1]-1);
    cv::Mat frame;
    src_video >> frame;
    op_frames.push_back(frame);
  }
//  int bit_stream_sum = (iter->second[0].rows/EIGHT) * (iter->second[0].cols/EIGHT);
  int len = LOGO_HEIGHT*LOGO_WIDTH;
  for (int i = 0; i < key_frame_pos[0]; ++i) {
    DivideToBlock(op_frames[i], frame_vector, bit_stream, len);
  }
  src_video.set(cv::CAP_PROP_POS_FRAMES, 0);
  long totol_frames = src_video.get(cv::CAP_PROP_FRAME_COUNT);
  std::stringstream path;
  path << PATH << "/output.avi";
  cv::VideoWriter dst_video;
  dst_video.open(path.str(),
                 dst_video.fourcc('M', 'P', 'E', 'G'),
                 src_video.get(cv::CAP_PROP_FPS),
                 cv::Size(src_video.get(cv::CAP_PROP_FRAME_WIDTH), src_video.get(cv::CAP_PROP_FRAME_HEIGHT)),
                 1);
  for (long j = 0, k = 0; j < totol_frames; ++j) {
    cv::Mat frame;
    src_video >> frame;
    int flag = 1;
    if (j == key_frame_pos[k+1] + k && k < key_frame_pos[0]) {
//      cv::resize(iter->second[0], iter->second[0],
//          cv::Size(src_video.get(cv::CAP_PROP_FRAME_WIDTH), src_video.get(cv::CAP_PROP_FRAME_HEIGHT)));
//      cv::resize(iter->second[1], iter->second[1],
//          cv::Size(src_video.get(cv::CAP_PROP_FRAME_WIDTH), src_video.get(cv::CAP_PROP_FRAME_HEIGHT)));
      dst_video << frame_vector[k * 2];
      dst_video << frame_vector[k*2+1];
      if (!model) {
        path.clear();
        path.str("");
        path << PATH << "/key-frame-2/0" << k * 2 << ".png";
        cv::imwrite(path.str(), frame_vector[k * 2]);
        path.clear();
        path.str("");
        path << PATH << "/key-frame-2/0" << k*2+1 << ".png";
        cv::imwrite(path.str(), frame_vector[k*2+1]);
//        cv::putText(frame, "Key Frame", cv::Point(0, 200), cv::FONT_HERSHEY_SIMPLEX, 5, cv::Scalar(0, 255, 0), 2, cv::LINE_8, false);
      }
      k++;
//      flag = 0;
    } else {
//      cv::resize(frame, frame,
//          cv::Size(src_video.get(cv::CAP_PROP_FRAME_WIDTH), src_video.get(cv::CAP_PROP_FRAME_HEIGHT)));
      dst_video << frame;
    }
    cv::imshow("SHOW", frame);
    cv::waitKey(flag);
  }
  dst_video.release();
  delete key_frame_pos;
}

void GetWatermark(cv::VideoCapture src_video) {
  long* key_frame_pos = GetKeyFrameByFile();
  std::vector<cv::Mat> info_frames;
  for (int i = 0, k = 0; i < key_frame_pos[0]; ++i) {
    src_video.set(cv::CAP_PROP_POS_FRAMES, key_frame_pos[i+1]+k);
    for (int j = 0; j < 2; ++j) {
      cv::Mat frame;
      src_video >> frame;
      info_frames.push_back(frame);
    }
    k += 2;
  }
  int len = LOGO_HEIGHT*LOGO_WIDTH;
  for (int l = 0; l < key_frame_pos[0]-1; ++l) {
    double *cmpl = new double[len];
    double *cmpr = new double[len];
    GetBlockInfo(info_frames[l * 2], cmpl, len);
    GetBlockInfo(info_frames[l*2+1], cmpr, len);
    cv::Mat dst_logo = cv::Mat::zeros(LOGO_HEIGHT, LOGO_WIDTH, CV_8UC1);
    for (int i = 0, k = 0; i < LOGO_HEIGHT; ++i) {
      for (int j = 0; j < LOGO_WIDTH; ++j) {
        if (cmpl[k] > cmpr[k]) {
          dst_logo.at<uchar>(i, j) = 255;
        }
        k++;
      }
    }
    delete []cmpl;
    delete []cmpr;
    cv::putText(dst_logo, std::to_string(l), cv::Point(0, 20), cv::FONT_HERSHEY_SIMPLEX, 1, cv::Scalar(0), 2, cv::LINE_8, false);
    cv::imshow("LOGO SHOW", dst_logo);
    cv::waitKey(0);
  }
  delete key_frame_pos;
}

// Test OpenSSL
std::string sha256(const std::string str) {
  char buf[2];
  unsigned char hash[SHA256_DIGEST_LENGTH];
  SHA256_CTX sha256;
  SHA256_Init(&sha256);
  SHA256_Update(&sha256, str.c_str(), str.size());
  SHA256_Final(hash, &sha256);
  std::string new_string = "";
  for (int i = 0; i < SHA256_DIGEST_LENGTH; i++) {
    sprintf(buf, "%02x", hash[i]);
    new_string = new_string + buf;
  }
  return new_string;
}
