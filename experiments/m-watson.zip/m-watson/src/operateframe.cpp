// Copyright 2020 Honeby.
// License: MIT
// Author: Honbey
//
// Operate frame or image.

#include "src/operateframe.h"

const double cSensitivityTable[EIGHT][EIGHT] = {
   { 1.40,  1.01,  1.16,  1.66,  2.40,  3.43,  4.79,  6.56 },
   { 1.01,  1.45,  1.32,  1.52,  2.00,  2.71,  3.67,  4.93 },
   { 1.16,  1.32,  2.42,  2.59,  2.98,  3.64,  4.60,  5.88 },
   { 1.66,  1.52,  2.59,  3.77,  4.55,  5.30, 26.28,  7.60 },
   { 2.40,  2.00,  2.98,  4.55,  6.15,  7.46,  8.71, 10.17 },
   { 2.43,  2.71,  3.64,  5.30,  7.46,  9.62, 11.58, 13.51 },
   { 4.79,  3.68,  4.60,  6.28,  8.71, 11.58, 14.50, 17.29 },
   { 6.56,  4.93,  5.88,  7.60, 10.17, 13.51, 17.29, 21.15 }
};

void DivideToBlock(const cv::Mat &src_rgb, std::vector<cv::Mat> &dst_vector, const bool *flag_array, const int cnt) {
  cv::Mat src_frame;
  src_rgb.copyTo(src_frame);
  cv::cvtColor(src_frame, src_frame, cv::COLOR_BGR2YCrCb);
  cv::Mat dst_mat_y;
  cv::Mat frame = cv::Mat::zeros(src_frame.rows, src_frame.cols, CV_8UC1);
  cv::Mat frame_prime = cv::Mat::zeros(src_frame.rows, src_frame.cols, CV_8UC1);
  std::vector<cv::Mat> channels;
  cv::split(src_frame, channels);
  dst_mat_y = channels[0];
  int pos = 0;
  long row_length = src_frame.rows/EIGHT, col_length = src_frame.cols/EIGHT;
  double total_luminance_mean = cv::mean(dst_mat_y)[0];
  for (long i = 0; i < row_length; ++i) {
    for (long j = 0; j < col_length; ++j) {
      cv::Rect roi(j*EIGHT, i*EIGHT, EIGHT, EIGHT);
      cv::Mat frame_roi = cv::Mat::zeros(EIGHT, EIGHT, CV_64FC1);
      dst_mat_y(roi).convertTo(frame_roi, CV_64FC1);
      cv::Mat f_u_v = cv::Mat::zeros(EIGHT, EIGHT, CV_64FC1);
      cv::Mat f_u_v_prime = cv::Mat::zeros(EIGHT, EIGHT, CV_64FC1);
      cv::dct(frame_roi, f_u_v);
      cv::dct(frame_roi, f_u_v_prime);
      cv::Mat block_mat = cv::Mat::zeros(EIGHT, EIGHT, CV_64FC1);
      ContrastMask(frame_roi, LuminanceParam(frame_roi, total_luminance_mean), block_mat);
//      for (int ii = 0; ii < EIGHT; ++ii) {
//        for (int jj = 0; jj < EIGHT; ++jj) {
//          printf("(%lf) ",block_mat.at<double>(ii,jj));
//        }
//        printf("\n");
//      }
//      printf("\n");
      if (pos < cnt) {
        if (flag_array[pos]) {
          f_u_v       = f_u_v       + block_mat;
          f_u_v_prime = f_u_v_prime - block_mat;
        } else {
          f_u_v       = f_u_v       - block_mat;
          f_u_v_prime = f_u_v_prime + block_mat;
        }
        pos++;
      }
      cv::idct(f_u_v      , f_u_v);
      cv::idct(f_u_v_prime, f_u_v_prime);
      f_u_v.copyTo(frame(roi));
      f_u_v_prime.copyTo(frame_prime(roi));
    }
  }
  cv::Mat tmp_frame = cv::Mat::zeros(src_frame.rows, src_frame.cols, CV_8UC3);
  cv::Mat tmp_frame_prime = cv::Mat::zeros(src_frame.rows, src_frame.cols, CV_8UC3);
  channels[0] = frame;
  cv::merge(channels, tmp_frame);
  cv::cvtColor(tmp_frame, tmp_frame, cv::COLOR_YCrCb2BGR);
  dst_vector.push_back(tmp_frame);
  channels[0] = frame_prime;
  cv::merge(channels, tmp_frame_prime);
  cv::cvtColor(tmp_frame_prime, tmp_frame_prime, cv::COLOR_YCrCb2BGR);
  dst_vector.push_back(tmp_frame_prime);
//  cv::imshow("0", dst_mat_rgb[0]);
//  cv::imshow("1", dst_mat_rgb[1]);
//  cv::waitKey(0);
//  cv::destroyAllWindows();
}

void GetBlockInfo(const cv::Mat src_frame, double *dst_array, const int cnt) {
  cv::Mat tmp = cv::Mat::zeros(src_frame.rows, src_frame.cols, CV_8UC3);
  src_frame.copyTo(tmp);
  cv::cvtColor(tmp, tmp, cv::COLOR_BGR2YCrCb);
  cv::Mat dst_mat_y;
  std::vector<cv::Mat> channels;
  cv::split(tmp, channels);
  dst_mat_y = channels[0];
  long row_length = tmp.rows/EIGHT, col_length = tmp.cols/EIGHT;
  int pos = 0;
  for (long i = 0; i < row_length; ++i) {
    for (long j = 0; j < col_length; ++j) {
      cv::Rect roi(j*EIGHT, i*EIGHT, EIGHT, EIGHT);
      cv::Mat frame_roi = cv::Mat::zeros(EIGHT, EIGHT, CV_64FC1);
      dst_mat_y(roi).convertTo(frame_roi, CV_64FC1);
      cv::dct(frame_roi, frame_roi);
      if (pos < cnt) {
        dst_array[pos] = cv::sum(frame_roi)[0];
        pos++;
      }
    }
  }
}

inline double LuminanceParam(const cv::Mat src_roi, const double total_luminance_mean) {
  double local_luminance_mean = cv::mean(src_roi)[0];
  double local_luminance_param = cv::pow(local_luminance_mean/total_luminance_mean, 0.649);
  return local_luminance_param;
}

inline void ContrastMask(const cv::Mat src_block, const double luminance_param, cv::Mat &block_contrast_table) {
  bool first_call = true;
  for (int i = 0; i < EIGHT; ++i) {
    double w_i_j = 0.7;
    if (first_call) {
      first_call = false;
      w_i_j = 0.0;
    }
    for (int j = 0; j < EIGHT; ++j) {
      if ((i == 7 && j == 0) ||
          (i == 6 && j == 1) ||
          (i == 5 && j == 2) ||
          (i == 4 && j == 3) ||
          (i == 3 && j == 5) ||
          (i == 2 && j == 4) ||
          (i == 1 && j == 6) ||
          (i == 0 && j == 7)) {
        double tmp_param1 = cSensitivityTable[i][j] * luminance_param;
        double tmp_param2 = cv::pow(cv::abs(src_block.at<double>(i, j)), w_i_j) * cv::pow(tmp_param1, 1.0 - w_i_j);
        block_contrast_table.at<double>(i, j) = MAX(tmp_param1, tmp_param2); // use MAX is too obvious
      }
    }
  }
}
