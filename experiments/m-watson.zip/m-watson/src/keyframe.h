// Copyright 2020 Honeby.
// License: MIT
// Author: Honbey
//
// Contain definition of function which
// can get the key frame from input video.

#ifndef MWATSON_SRC_KEYFRAME_H_
#define MWATSON_SRC_KEYFRAME_H_

#include "src/mwatson.h"

// open video or camera and get key frame
void GetKeyFrameByFrameDiff(cv::VideoCapture src_capture, bool visible=false);
double JudgeSimilarity(cv::Mat current_frame, cv::Mat previous_frame);

std::string HashValue(const cv::Mat &src);
int CalcDistance(const std::string &str1, const std::string &str2);

struct Shot;
const std::array<float, 22> operator+(const std::array<float, 22> &src_left, std::array<float, 22> &src_right);
const std::array<float, 22> operator/(const std::array<float, 22> &src_left, int &src_right);
std::array<float, 22> SumOfContent(std::list<std::array<float, 22>> &content);
int FindMaxEntropyFrame(std::list<std::array<float, 22>> frames, std::list<int> pos_list);
float CalcSimilarity(std::array<float, 22> current_frame, std::array<float, 22> previous_frame);
void CombineShot(std::vector<Shot> &shot, int i, int j);
void GetKeyFrameByCluster(cv::VideoCapture &cap);

#endif // MWATSON_SRC_KEYFRAME_H_
