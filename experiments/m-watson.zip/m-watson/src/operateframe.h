// Copyright 2020 Honeby.
// License: MIT
// Author: Honbey
//
// Contain definition of function which
// can operate frame or image.

#ifndef MWATSON_SRC_OPERATEFRAME_H_
#define MWATSON_SRC_OPERATEFRAME_H_

#include "src/mwatson.h"

void DivideToBlock(const cv::Mat &src_rgb, std::vector<cv::Mat> &dst_vector, const bool *flag_array, const int cnt);
void GetBlockInfo(const cv::Mat src_frame, double *dst_array, const int cnt);
double LuminanceParam(const cv::Mat src_roi, const double total_luminance_mean);
void ContrastMask(const cv::Mat src_block, const double luminance_param, cv::Mat &block_contrast_table);

#endif // MWATSON_SRC_OPERATEFRAME_H_
