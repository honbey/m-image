// Copyright 2020 Honeby.
// License: MIT
// Author: Honbey
//
// Get the key frame from input video.

#include "src/keyframe.h"

void GetKeyFrameByFrameDiff(cv::VideoCapture src_capture, bool visible) {
  std::vector<long> frames_pos;
  cv::Mat key_frame, frame;
  src_capture >> key_frame;
  if (key_frame.empty()) {
    printf("key frame is empty!\n");
  } else {
    std::stringstream path;
    path << PATH << "/key-frame/1.png";
    cv::imwrite(path.str(), key_frame);
    std::vector<cv::Mat> tmp;
    cv::Mat tmp_;
    key_frame.copyTo(tmp_);
    tmp.push_back(tmp_);
    cv::imwrite(path.str(), key_frame);
    frames_pos.push_back(0);
  }
  long total_frame = src_capture.get(cv::CAP_PROP_FRAME_COUNT);
  if (visible) cv::namedWindow("Video Show");
  for (long pos = 1; pos < total_frame; ++pos) {
    src_capture >> frame;
    if (frame.empty()) {
      printf("frame is empty!\n");
      break;
    }
    if (visible) {
      cv::imshow("Video Show", frame);
      cv::waitKey(src_capture.get(cv::CAP_PROP_FPS));
    }
    if (JudgeSimilarity(frame, key_frame) > DIFF_RATIO) {
      frame.copyTo(key_frame);
//      std::stringstream path;
//      path << PATH << "/key-frame/" << pos << ".png";
//      cv::imwrite(path.str(), key_frame);
      frames_pos.push_back(pos);
    }
  }
  std::fstream write_frame_pos;
  write_frame_pos.open("frame-index.txt", std::ios::out);
  for (size_t i = 0; i < frames_pos.size(); ++i) {
    write_frame_pos << std::to_string(frames_pos[i]) << std::endl;
  }
  write_frame_pos.close();
//  cv::destroyAllWindows();
//  cv::waitKey(0);
}

double JudgeSimilarity(const cv::Mat current_frame, const cv::Mat previous_frame) {
  cv::Mat current_gray, previous_gray, current_origin, previous_origin, diff_mat;
  current_frame.copyTo(current_origin);
  previous_frame.copyTo(current_origin);
  cv::cvtColor(current_frame, current_gray, cv::COLOR_BGR2GRAY);
  cv::cvtColor(previous_frame, previous_gray, cv::COLOR_BGR2GRAY);
  cv::absdiff(current_gray, previous_gray, diff_mat);
  cv::threshold(diff_mat, diff_mat, THRESHOLD_VALUE, 255.0, cv::THRESH_BINARY);
  double sum = static_cast<float>(diff_mat.rows * diff_mat.cols);
  double cnt = static_cast<float>(cv::countNonZero(diff_mat));
  return cnt/sum;
}

// https://blog.csdn.net/weixin_34200628/article/details/92004184
std::string HashValue(const cv::Mat &src) {
  cv::Mat img, dst;
  std::string rst(64, '\0');
  double dIdex[64];
  double mean = 0.0;
  int k = 0;
  if (src.channels() == 3) {
    cv::cvtColor(src, src, cv::COLOR_BGR2GRAY);
    img = cv::Mat_<double>(src);
  } else {
    img = cv::Mat_<double>(src);
  }
  cv::resize(img, img, cv::Size(8,8));
  cv::dct(img, dst);
  for (int i = 0; i < 8; ++i) {
    for (int j = 0; j < 8; ++j) {
      dIdex[k] = dst.at<double>(i, j);
      mean += dst.at<double>(i, j)/64.0;
      ++k;
    }
  }
  for (int i = 0; i<64; ++i) {
    if (dIdex[i] >= mean) {
      rst[i]='1';
    } else {
      rst[i]='0';
    }
  }
  return rst;
}

int CalcDistance(const std::string &str1, const std::string &str2) {
  if ((str1.size() != 64) || (str2.size() != 64)) return -1;
  int dst_difference = 0;
  for (int i = 0; i < 64; ++i) {
    if (str1[i] != str2[i])
      dst_difference++;
  }
  return dst_difference;
}

struct Shot {
  std::list<std::array<float, 22>> content;
  std::list<int> pos;
  std::array<float, 22> center;
};

float CalcSimilarity(std::array<float, 22> current_frame, std::array<float, 22> previous_frame) {
  float h = 0, s = 0, v = 0;
  for (int i = 0 ; i < 12; ++i) {
    h += MIN(current_frame[i], previous_frame[i]);
  }
  for (int i = 12; i < 17; ++i) {
    s += MIN(current_frame[i], previous_frame[i]);
  }
  for (int i = 17; i < 22; ++i) {
    v += MIN(current_frame[i], previous_frame[i]);
  }
  return 0.5*h + 0.3*s + 0.2*v;
}

int FindMaxEntropyFrame(std::list<std::array<float, 22>> frames, std::list<int> pos_list) {
  std::list<std::array<float, 22>>::iterator f_iter;
  std::list<int>::iterator p_iter = pos_list.begin();
  int pos = 0;
  float max = 0.0;
  for (f_iter = frames.begin(); f_iter != frames.end(); ++f_iter, ++p_iter) {
    float h = 0, s = 0, v = 0;
    for (int i = 0 ; i < 12; ++i) {
      if ((*f_iter)[i] != 0) {
        h += -(*f_iter)[i] * cv::log((*f_iter)[i])/cv::log(2.0);
      }
    }
    for (int i = 12; i < 17; ++i) {
      if ((*f_iter)[i] != 0) {
        s += -(*f_iter)[i] * cv::log((*f_iter)[i])/cv::log(2.0);
      }
    }
    for (int i = 17; i < 22; ++i) {
      if ((*f_iter)[i] != 0) {
        v += -(*f_iter)[i] * cv::log((*f_iter)[i])/cv::log(2.0);
      }
    }
    float entropy = 0.5*h + 0.3*s + 0.2*v;
    if (entropy > max) {
      max = entropy;
      pos = *p_iter;
    }
  }
  return pos;
}

const std::array<float, 22> operator+(const std::array<float, 22> &src_left, std::array<float, 22> &src_right) {
  std::array<float, 22> ans;
  for (int i = 0; i < 22; ++i) {
    ans[i] = src_left[i] + src_right[i];
  }
  return ans;
}

const std::array<float, 22> operator/(const std::array<float, 22> &src_left, int &src_right) {
  std::array<float, 22> ans;
  for (int i = 0; i < 22; ++i) {
    ans[i] = src_left[i] / src_right;
  }
  return ans;
}

inline void CombineShot(std::vector<Shot> &shot, int i, int j) {
  std::list<std::array<float, 22>>::iterator f_iter;
  std::list<int>::iterator p_iter = shot[j].pos.begin();
  std::vector<Shot>::iterator v_iter = shot.begin() + j;
  for (f_iter = shot[j].content.begin(); f_iter != shot[j].content.end(); ++f_iter, ++p_iter) {
    shot[i].content.push_back(*f_iter);
    shot[i].center = *f_iter + shot[i].center;
    shot[i].pos.push_back(*p_iter);
  }
  shot.erase(v_iter);
}

inline std::array<float, 22> SumOfContent(std::list<std::array<float, 22>> &content) {
  std::array<float ,22> ans = { 0 };
  for (std::list<std::array<float, 22>>::iterator c_iter = content.begin();
       c_iter != content.end(); ++c_iter) {
    for (int i = 0; i < 22; ++i) {
      ans[i] += (*c_iter)[i];
    }
  }
  return ans;
}

void GetKeyFrameByCluster(cv::VideoCapture &cap) {
  std::list<std::array<float, 22>> color_bar;
  while (true) {
    cv::Mat frame;
    cap >> frame;
    if (frame.empty()) break;
    cv::cvtColor(frame, frame, cv::COLOR_BGR2HSV);
    std::array<float, 22> color = { 0 };
    uchar *h = new uchar[frame.rows * frame.cols];
    uchar *s = new uchar[frame.rows * frame.cols];
    uchar *v = new uchar[frame.rows * frame.cols];
    for (int i = 0; i < frame.rows; ++i) {
      for (int j = 0; j < frame.cols; ++j) {
        h[i*frame.rows+j] = static_cast<uchar>(frame.at<cv::Vec3b>(i, j)[0]/21);
        if (h[i*frame.rows+j] > 11) h[i*frame.rows+j] = 11;
        s[i*frame.rows+j] = static_cast<uchar>(frame.at<cv::Vec3b>(i, j)[1]/51);
        if (s[i*frame.rows+j] > 4) h[i*frame.rows+j] = 4;
        v[i*frame.rows+j] = static_cast<uchar>(frame.at<cv::Vec3b>(i, j)[2]/51);
        if (v[i*frame.rows+j] > 4) h[i*frame.rows+j] = 4;
        color[h[i*frame.rows+j]]++;
        color[12+s[i*frame.rows+j]]++;
        color[17+v[i*frame.rows+j]]++;
      }
    }
    for (int i = 0; i < 22; ++i) {
      color[i] /= frame.rows * frame.cols;
    }
    color_bar.push_back(color);
    delete [] h;
    delete [] s;
    delete [] v;
  }
  float threshold = 0.85;
  std::list<std::array<float, 22>>::iterator iter = color_bar.begin();
  ++iter;
  std::vector<Shot> shot;
  Shot first;
  first.content.push_back(*color_bar.begin());
  first.center = *color_bar.begin();
  first.pos.push_back(0);
  shot.push_back(first);
  int cnt = 0, num = 1, index = 0;
  for (; iter != color_bar.end(); ++iter) {
    float max = 0;
    index = 0;
    for (int i = 0; i < num; ++i) {
      float ratio = CalcSimilarity(*iter, shot[i].center);
      if (ratio > max) {
        max = ratio;
        index = i;
      }
    }
    if (max < threshold) {
      num += 1;
      Shot new_shot;
      new_shot.center = *iter;
      new_shot.content.push_back(*iter);
      new_shot.pos.push_back(cnt);
      shot.push_back(new_shot);
    } else {
      std::array<float, 22> tmp1 = SumOfContent(shot[index].content);
      int tmp2 = (shot[index].content.size()+1);
      shot[index].center = (*iter+tmp1) / tmp2;
      shot[index].content.push_back(*iter);
      shot[index].pos.push_back(cnt);
    }
    cnt += 1;
  }
  for (size_t i = 0; i < shot.size(); ++i) {
    if (shot[i].content.size() < 10 && i > 0) {
      CombineShot(shot, i-1, i);
      i -= 1;
    }
  }
  std::fstream write_frame_pos;
  write_frame_pos.open("frame-index.txt", std::ios::out);
  for (size_t i = 0; i < shot.size(); ++i) {
    int pos = FindMaxEntropyFrame(shot[i].content, shot[i].pos);
    printf("%d %d\n", *shot[i].pos.begin(), pos);
    write_frame_pos << std::to_string(*shot[i].pos.begin()) << std::endl;
  }
  write_frame_pos.close();
}
