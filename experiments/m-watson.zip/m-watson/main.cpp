// Copyright 2020 Honeby.
// License: MIT
// Author: Honbey
//
// Mian() function.

#include <QApplication>
#include "mainwindow.h"
#include "src/mwatson.h"
#include "src/keyframe.h"
#include "src/operateframe.h"
#include "src/watermark.h"

int main(int argc, char *argv[]) {
  QApplication a(argc, argv);
  std::stringstream path;
  path << PATH << "/SP7-2020.mp4";
  cv::VideoCapture cap(path.str());
//  GetKeyFrameByFrameDiff(cap);
//  GetKeyFrameByCluster(cap);
//  std::string cmd = "/usr/local/bin/ffprobe -i " + path.str() + " -select_streams v -show_frames -show_entries frame=pict_type -of csv | grep -n I | cut -d ':' -f 1 > frame-index.txt";
//  system(cmd.c_str());
  path.clear();
  path.str("");
  path << PATH << "/bilibili-logo.png";
  cv::Mat logo = cv::imread(path.str());
  bool *p;
  p = GetWatermarkArray(logo);
  InsertWatermark(cap, p, false);
  path.clear();
  path.str("");
  path << PATH << "/output.avi";
  cap.open(path.str());
  GetWatermark(cap);

  delete [] p;
  cap.release();
  return 0;
  return a.exec();
}
