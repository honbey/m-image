# M-Watson
Watermarking program about videos based on Watson model.

---

The Watermarking algorithm refers to the following paper：
> [Reference Link](https://kns.cnki.net/kcms/detail/detail.aspx?filename=FJFQ201105006&dbcode=CJFQ&dbname=CJFD2011&v=)
